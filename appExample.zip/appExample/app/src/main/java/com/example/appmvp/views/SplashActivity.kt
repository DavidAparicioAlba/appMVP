package com.example.appmvp.views

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.appmvp.R
import kotlinx.android.synthetic.main.activity_splash.*



private val MAX_STIFFNESS = SpringForce.STIFFNESS_HIGH
private val MIN_STIFFNESS = 1
private val MAX_DAMPING_RATIO = 1
private val MIN_DAMPING_RATIO = 0

class SplashActivity : AppCompatActivity() {

    var circ:ImageView?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        circ=circle
        circ?.animate()?.translationX(300.toFloat())?.setDuration(2000)?.start()

        circ?.animate()?.setStartDelay(2000)?.translationX(-600.toFloat())?.setDuration(2000)?.alpha(0.toFloat())

        Handler().postDelayed({
            startActivity(Intent(this, InitActivity::class.java))
        }, 6000)

    }
}
